﻿using System.Collections.Generic;
using System.Linq;
using DAO_EFCORE.DAL.Models;

namespace DAO_EFCORE.DAL.Persistence
{
    public class NoteRepository : INoteRepository
    {
        private readonly IKeepNoteContext context;

        public NoteRepository(IKeepNoteContext dbContext)
        {
            context = dbContext;
        }

        //Implement INoteRepository
        public Checklist AddChecklist(Checklist checklist)
        {
            context.Checklists.Add(checklist);
            if (context.SaveChanges() > 0)
            {
                return checklist;
            }
            else
            {
                return new Checklist();
            }
        }

        public Label AddLabel(Label label)
        {
            context.Labels.Add(label);
            if (context.SaveChanges() > 0)
            {
                return label;
            }
            else
            {
                return new Label();
            }
        }

        public Note AddNote(Note note)
        {
            context.Notes.Add(note);
            if (context.SaveChanges() > 0)
            {
                return note;
            }
            else
            {
                return new Note();
            }
        }

        public List<Checklist> GetAllCheckListItems(int noteId)
        {
            return context.Checklists.Where(i => i.Note.NoteId == noteId).ToList();
        }

        public List<Label> GetAllLabels(int noteId)
        {
            return context.Labels.Where(i => i.Note.NoteId == noteId).ToList();
        }

        public List<Note> GetAllNotes()
        {
            return context.Notes.ToList();
        }

        public Note GetNote(int noteId)
        {
            return context.Notes.FirstOrDefault(i => i.NoteId == noteId);
        }

        public bool RemoveChecklist(int id)
        {
            var checklistToRemove = context.Checklists.FirstOrDefault(i => i.ChecklistId == id);
            context.Checklists.Remove(checklistToRemove);
            int rowsAffected = context.SaveChanges();
            return rowsAffected > 0;
        }

        public bool RemoveLabel(int id)
        {
            var labelToRemove = context.Labels.FirstOrDefault(i => i.LabelId == id);
            context.Labels.Remove(labelToRemove);
            int rowsAffected = context.SaveChanges();
            return rowsAffected > 0;
        }

        public bool RemoveNote(int id)
        {
            var noteToRemove = context.Notes.FirstOrDefault(i => i.NoteId == id);
            context.Notes.Remove(noteToRemove);
            int rowsAffected = context.SaveChanges();
            return rowsAffected > 0;
        }

        public bool UpdateChecklist(Checklist checklist)
        {
            var checklistToUpdate = context.Checklists.FirstOrDefault(i => i.ChecklistId == checklist.ChecklistId);
            checklistToUpdate.Content = checklist.Content;
            int rowsAffected = context.SaveChanges();
            return rowsAffected > 0;
        }

        public bool UpdateLabel(Label label)
        {
            var labelToUpdate = context.Labels.FirstOrDefault(i => i.LabelId == label.LabelId);
            labelToUpdate.Content = label.Content;
            int rowsAffected = context.SaveChanges();
            return rowsAffected > 0;
        }
    }
}
