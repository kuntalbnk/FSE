﻿namespace DAO_EFCORE.DAL.Models
{
    public class Label
    {
        //Define Label entity
        public int LabelId { get; set; }
        public string Content { get; set; }

        // Navigation Property
        public int NoteId { get; set; }
        public Note Note { get; set; }
    }
}
