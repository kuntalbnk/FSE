﻿namespace DAO_EFCORE.DAL.Models
{
    public class Checklist
    {
        //Define checklist entity
        public int ChecklistId { get; set; }
        public string Content { get; set; }

        // Navigation Property
        public int NoteId { get; set; }
        public Note Note { get; set; }
    }
}
