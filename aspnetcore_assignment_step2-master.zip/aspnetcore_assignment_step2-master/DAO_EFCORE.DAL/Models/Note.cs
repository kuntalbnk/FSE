﻿using System.Collections.Generic;

namespace DAO_EFCORE.DAL.Models
{
    public class Note
    {
        //To-Do define Note Entity
        public int NoteId { get; set; }
        public string Title { get; set; }

        // Navigation Property
        public virtual ICollection<Checklist> ListItems { get; set; }
        public virtual ICollection<Label> Labels { get; set; }
    }
}
