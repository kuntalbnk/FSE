﻿using Microsoft.EntityFrameworkCore;

namespace DAO_EFCORE.DAL.Models
{
    public class KeepNoteContext : DbContext, IKeepNoteContext
    {
        //Implement KeepNoteContext class
        public KeepNoteContext() { }
        public KeepNoteContext(DbContextOptions<KeepNoteContext> options) : base(options)
        {
            Database.EnsureCreated();
        }

        DbSet<Note> IKeepNoteContext.Notes { get; set; }
        DbSet<Label> IKeepNoteContext.Labels { get; set; }
        DbSet<Checklist> IKeepNoteContext.Checklists { get; set; }

        //Use Fluent API to configure relationship
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Note>()
                .HasKey(n => n.NoteId);
            modelBuilder.Entity<Note>()
                .Property(n => n.Title)
                .IsRequired();
            
            modelBuilder.Entity<Checklist>()
                .HasKey(c => c.ChecklistId);
            modelBuilder.Entity<Checklist>()
                .Property(c => c.Content)
                .IsRequired();
            modelBuilder.Entity<Checklist>()
                .HasOne(c => c.Note)
                .WithMany(c => c.ListItems)
                .HasForeignKey(c => c.NoteId)
                .HasConstraintName("ForeignKey_Checklist_Note");

            modelBuilder.Entity<Label>()
                .HasKey(c => c.LabelId);
            modelBuilder.Entity<Label>()
                .Property(c => c.Content)
                .IsRequired();
            modelBuilder.Entity<Label>()
                .HasOne(c => c.Note)
                .WithMany(c => c.Labels)
                .HasForeignKey(c => c.NoteId)
                .HasConstraintName("ForeignKey_Label_Note");
        }
    }
}
