﻿using DAO_EFCORE.DAL.Models;
using DAO_EFCORE.DAL.Persistence;
using DAO_EFCORE.Business.Exceptions;
using System.Collections.Generic;

namespace DAO_EFCORE.Business
{
    public class NoteService : INoteService
    {
        private INoteRepository repository;

        public NoteService(INoteRepository noteRepository)
        {
            repository = noteRepository;
        }

        public Checklist AddChecklist(int noteId, Checklist checklist)
        {
            checklist.NoteId = noteId;
            return repository.AddChecklist(checklist);
        }

        public Label AddLabel(int noteId, Label label)
        {
            label.NoteId = noteId;
            return repository.AddLabel(label);
        }

        public Note AddNote(Note note)
        {
            return repository.AddNote(note);
        }

        public List<Checklist> GetAllCheckListItems(int noteId)
        {
            List<Checklist> checklists;
            try
            {
                checklists = repository.GetAllCheckListItems(noteId);
                if (ReferenceEquals(checklists, null) || checklists.Count == 0)
                {
                    throw new NoteNotFoundException("Note with this id " + noteId + " does not exist");
                }
            }
            catch (System.Exception ex)
            {
                throw new NoteNotFoundException("Note with this id " + noteId + " does not exist");
            }
            return checklists;
        }

        public List<Label> GetAllLabels(int noteId)
        {
            List<Label> labels;
            try
            {
                labels = repository.GetAllLabels(noteId);
                if (ReferenceEquals(labels, null) || labels.Count == 0)
                {
                    throw new NoteNotFoundException("Note with this id " + noteId + " does not exist");
                }
            }
            catch (System.Exception ex)
            {
                throw new NoteNotFoundException("Note with this id " + noteId + " does not exist");
            }
            return labels;
        }

        public List<Note> GetAllNotes()
        {
            List<Note> notes;
            try
            {
                notes = repository.GetAllNotes();
                if (ReferenceEquals(notes, null) || notes.Count == 0)
                {
                    throw new NoteNotFoundException("Note does not exist");
                }
            }
            catch (System.Exception)
            {
                throw new NoteNotFoundException("Note does not exist");
            }
            return notes;
        }

        public Note GetNote(int noteId)
        {
            Note note;
            try
            {
                note = repository.GetNote(noteId);
                if (ReferenceEquals(note, null))
                {
                    throw new NoteNotFoundException("Note with this id " + noteId + " does not exist");
                }
            }
            catch (System.Exception ex)
            {
                throw new NoteNotFoundException("Note with this id " + noteId + " does not exist");
            }
            return note;
        }

        public List<Note> GetNotesByLabel(string lblText)
        {
            return repository.GetAllNotesByLabel(lblText);
        }

        public List<Note> GetNotesByTitle(string title)
        {
            return repository.GetAllNotesByTitle(title);
        }

        public bool RemoveChecklist(int noteId, int id)
        {
            bool status = false;
            try
            {
                status = repository.RemoveChecklist(id);
                if (!status)
                {
                    throw new ChecklistNotFoundException("Checklist item with id " + id + " not found");
                }
            }
            catch (System.Exception ex)
            {
                throw new ChecklistNotFoundException("Checklist item with id " + id + " not found");
            }
            return status;
        }

        public bool RemoveLabel(int noteId, int id)
        {
            bool status = false;
            try
            {
                status = repository.RemoveLabel(id);
                if (!status)
                {
                    throw new LabelNotFoundException("A label with id " + id + " does not exist");
                }
            }
            catch (System.Exception ex)
            {
                throw new LabelNotFoundException("A label with id " + id + " does not exist");
            }
            return status;
        }

        public bool RemoveNote(int noteId)
        {
            bool status = false;
            try
            {
                status = repository.RemoveNote(noteId);
                if (!status)
                {
                    throw new NoteNotFoundException("Note with this id " + noteId + " does not exist");
                }
            }
            catch (System.Exception ex)
            {
                throw new NoteNotFoundException("Note with this id " + noteId + " does not exist");
            }
            return status;
        }

        public bool UpdateChecklist(int noteId, Checklist checklist)
        {
            bool status = false;
            try
            {
                status = repository.UpdateChecklist(checklist);
                if (!status)
                {
                    throw new LabelNotFoundException("Checklist item with id " + checklist.ChecklistId + " not found");
                }
            }
            catch (System.Exception ex)
            {
                throw new LabelNotFoundException("Checklist item with id " + checklist.ChecklistId + " not found");
            }
            return status;
        }

        public bool UpdateLabel(int noteId, Label label)
        {
            bool status = false;
            try
            {
                status = repository.UpdateLabel(label);
                if (!status)
                {
                    throw new LabelNotFoundException("A label with id " + label.LabelId + " does not exist");
                }
            }
            catch (System.Exception ex)
            {
                throw new LabelNotFoundException("A label with id " + label.LabelId + " does not exist");
            }
            return status;
        }
    }
}
