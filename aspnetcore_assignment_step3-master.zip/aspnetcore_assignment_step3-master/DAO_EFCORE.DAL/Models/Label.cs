﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;

namespace DAO_EFCORE.DAL.Models
{
    public class Label
    {
        public int LabelId { get; set; }
        public string Content { get; set; }

        // Navigation Property
        public int NoteId { get; set; }
        public virtual Note Note { get; set; }
    }
}
