﻿using System;
using System.Collections.Generic;
using System.Net;
using DAO_EFCORE.Business;
using DAO_EFCORE.Business.Exceptions;
using DAO_EFCORE.DAL.Models;
using Microsoft.AspNetCore.Mvc;

namespace DAO_EFCORE.API.Controllers
{
    [Route("api/[controller]")]
    public class NotesController : Controller
    {
        private INoteService service;

        public NotesController(INoteService noteService)
        {
            service = noteService;
        }

        //implementation of all required routes

        [HttpGet]
        public IActionResult Get()
        {
            List<Note> notes = new List<Note>();
            try
            {
                notes = service.GetAllNotes();
            }
            catch (NoteNotFoundException ex)
            {
                return new NotFoundObjectResult(ex.Message);
            }
            catch (Exception)
            {
                return new NotFoundObjectResult(notes);
            }
            return new OkObjectResult(notes);
        }

        [Route("{id}")]
        [HttpGet]
        public IActionResult Get(int id)
        {
            Note note = new Note();
            try
            {
                note = service.GetNote(id);
            }
            catch (NoteNotFoundException ex)
            {
                return new NotFoundObjectResult(ex.Message);
            }
            catch (Exception)
            {
                return new NotFoundObjectResult(note);
            }
            return new OkObjectResult(note);
        }

        [HttpPost]
        public IActionResult Post(Note note)
        {
            Note addedNote = new Note();
            try
            {
                addedNote = service.AddNote(note);
            }
            catch (Exception)
            {
                return new NotFoundObjectResult(addedNote);
            }
            return new CreatedResult("api/notes", addedNote);
        }

        [Route("{id}")]
        [HttpDelete]
        public IActionResult Delete(int id)
        {
            bool status = false;
            try
            {
                status = service.RemoveNote(id);
            }
            catch (NoteNotFoundException ex)
            {
                return new NotFoundObjectResult(ex.Message);
            }
            catch (Exception)
            {
                return new NotFoundObjectResult(status);
            }
            return new OkObjectResult(status);
        }

        [Route("{id}/labels")]
        [HttpPost]
        public IActionResult AddLabel(int id, Label label)
        {
            Label addedLabel = new Label();
            try
            {
                addedLabel = service.AddLabel(id, label);
            }
            catch (Exception)
            {
                return new NotFoundObjectResult(addedLabel);
            }
            return new CreatedResult("api/notes/{id}/labels", addedLabel);
        }

        [Route("{id}/labels/{labelId}")]
        [HttpDelete]
        public IActionResult RemoveLabel(int id, int labelId)
        {
            bool status = false;
            try
            {
                status = service.RemoveLabel(id, labelId);
            }
            catch (LabelNotFoundException ex)
            {
                return new NotFoundObjectResult(ex.Message);
            }
            catch (Exception)
            {
                return new NotFoundObjectResult(status);
            }
            return new OkObjectResult(status);
        }

        [Route("{id}/labels/{labelId}")]
        [HttpPut]
        public IActionResult UpdateLabel(int id, int labelId, Label label)
        {
            bool status = false;
            try
            {
                status = service.UpdateLabel(id, label);
            }
            catch (LabelNotFoundException ex)
            {
                return new NotFoundObjectResult(ex.Message);
            }
            catch (Exception)
            {
                return new NotFoundObjectResult(status);
            }
            return new OkObjectResult(status);
        }

        [Route("{id}/checklist")]
        [HttpPost]
        public IActionResult AddChecklist(int id, Checklist checklist)
        {
            Checklist addedChecklist = new Checklist();
            try
            {
                addedChecklist = service.AddChecklist(id, checklist);
            }
            catch (Exception)
            {
                return new NotFoundObjectResult(addedChecklist);
            }
            return new CreatedResult("api/notes/{id}/checklist", addedChecklist);
        }

        [Route("{id}/checklist/{itemId}")]
        [HttpDelete]
        public IActionResult RemoveChecklist(int id, int itemId)
        {
            bool status = false;
            try
            {
                status = service.RemoveChecklist(id, itemId);
            }
            catch (ChecklistNotFoundException ex)
            {
                return new NotFoundObjectResult(ex.Message);
            }
            catch (Exception)
            {
                return new NotFoundObjectResult(status);
            }
            return new OkObjectResult(status);
        }

        [Route("{id}/checklist/{itemId}")]
        [HttpPut]
        public IActionResult UpdateChecklist(int id, int itemId, Checklist checklist)
        {
            bool status = false;
            try
            {
                status = service.UpdateChecklist(id, checklist);
            }
            catch (LabelNotFoundException ex)
            {
                return new NotFoundObjectResult(ex.Message);
            }
            catch (Exception)
            {
                return new NotFoundObjectResult(status);
            }
            return new OkObjectResult(status);
        }

        [Route("getbylabel/{lblText}")]
        [HttpGet]
        public IActionResult GetNotesByLabel(string lblText)
        {
            List<Note> notes = new List<Note>();
            try
            {
                notes = service.GetNotesByLabel(lblText);
            }
            catch (Exception)
            {
                return new NotFoundObjectResult(notes);
            }
            return new OkObjectResult(notes);
        }

        [Route("getbytitle/{title}")]
        [HttpGet]
        public IActionResult GetNotesByTitle(string title)
        {
            List<Note> notes = new List<Note>();
            try
            {
                notes = service.GetNotesByTitle(title);
            }
            catch (Exception)
            {
                return new NotFoundObjectResult(notes);
            }
            return new OkObjectResult(notes);
        }
    }
}
