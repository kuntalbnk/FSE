﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ReminderService.API.Exceptions;
using ReminderService.API.Models;
using ReminderService.API.Repository;

namespace ReminderService.API.Service
{
    public class ReminderService : IReminderService
    {
        public readonly IReminderRepository repository;

        public ReminderService(IReminderRepository reminderRepository)
        {
            repository = reminderRepository;
        }

        public Reminder CreateReminder(Reminder reminder)
        {
            Reminder createdReminder;
            try
            {
                createdReminder = repository.CreateReminder(reminder);
                if (ReferenceEquals(createdReminder, null))
                {
                    throw new Exception();
                }
            }
            catch
            {
                throw new ReminderNotCreatedException("This reminder id already exists");
            }

            return createdReminder;
        }

        public bool DeleteReminder(int reminderId)
        {
            try
            {
                if (repository.DeleteReminder(reminderId))
                {
                    return true;
                }
                else
                {
                    throw new Exception();
                }
            }
            catch
            {
                throw new ReminderNotFoundException("This reminder id not found");
            }
        }

        public List<Reminder> GetAllReminders()
        {
            return repository.GetAllReminders();
        }

        public Reminder GetReminderById(int reminderId)
        {
            Reminder reminder;
            try
            {
                reminder = repository.GetReminderById(reminderId);
                if (ReferenceEquals(reminder, null))
                {
                    throw new Exception();
                }
            }
            catch
            {
                throw new ReminderNotFoundException("This reminder id not found");
            }
            return reminder;
        }

        public bool UpdateReminder(int reminderId, Reminder reminder)
        {
            try
            {
                if (repository.UpdateReminder(reminderId, reminder))
                {
                    return true;
                }
                else
                {
                    throw new Exception();
                }
            }
            catch
            {
                throw new ReminderNotFoundException("This reminder id not found");
            }
        }
    }
}
