﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ReminderService.API.Models;
using ReminderService.API.Service;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ReminderService.API.Controllers
{
    [Authorize]
    [ExceptionHandler]
    [LoggingAspect]
    [Route("api/[controller]")]
    public class ReminderController : Controller
    {
        private readonly IReminderService service;

        public ReminderController(IReminderService _service)
        {
            this.service = _service;
        }

        // GET: api/<controller>
        [HttpGet]
        public IActionResult Get()
        {
            return Ok(service.GetAllReminders());
        }

        // GET api/<controller>/5
        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            return Ok(service.GetReminderById(id));
        }

        // POST api/<controller>
        [HttpPost]
        public IActionResult Post(Reminder reminder)
        {
            return Created("", service.CreateReminder(reminder));
        }

        // PUT api/<controller>/5
        [HttpPut("{id}")]
        public IActionResult Put(int id, Reminder reminder)
        {
            return Ok(service.UpdateReminder(id, reminder));
        }

        // DELETE api/<controller>/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            return Ok(service.DeleteReminder(id));
        }
    }
}
