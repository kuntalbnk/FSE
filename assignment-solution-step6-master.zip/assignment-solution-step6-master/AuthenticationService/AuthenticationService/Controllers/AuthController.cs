﻿using AuthenticationService.API.Models;
using AuthenticationService.Exceptions;
using AuthenticationService.Models;
using AuthenticationService.Service;
using Microsoft.AspNetCore.Mvc;
using System;

namespace AuthenticationService.Controllers
{
    [LoggingAspect]
    [Route("auth")]
    public class AuthController : Controller
    {
        private readonly IAuthService service;
        private readonly ITokenGenerator tokenGenerator;

        public AuthController(IAuthService _service, ITokenGenerator _tokenGenerator = null)
        {
            service = _service;
            tokenGenerator = _tokenGenerator;
        }

        // POST api/<controller>
        [HttpPost]
        [Route("register")]
        public IActionResult Register([FromBody]User user)
        {
            try
            {
                if (service.IsUserExist(user))
                {
                    return StatusCode(409, $"User with this id {user.UserId} already exists");
                }
                else
                {
                    service.RegisterUser(user);
                    return Created("", true);
                }
            }
            catch (UserNotCreatedException ex)
            {
                return Conflict();
            }
            catch (Exception ex)
            {
                return NotFound();
            }
        }

        [HttpPost]
        [Route("login")]
        public IActionResult Login([FromBody]User user)
        {
            try
            {
                User loggedInUser = service.LoginUser(user.UserId, user.Password);

                if (!ReferenceEquals(loggedInUser, null))
                {
                    //calling the function for the JWT token for respecting user
                    if (!ReferenceEquals(tokenGenerator, null))
                    {
                        string value = tokenGenerator.GetJWTToken(user.UserId);
                        //returning the token to the consumer app
                        return Ok(value);
                    }
                    else
                    {
                        return Ok(loggedInUser);
                    }
                }
                else
                {
                    return NotFound("User not found");
                }
            }
            catch (UserNotFoundException ex)
            {
                return NotFound();
            }
            catch (Exception ex)
            {
                return NotFound();
            }
        }
    }
}
