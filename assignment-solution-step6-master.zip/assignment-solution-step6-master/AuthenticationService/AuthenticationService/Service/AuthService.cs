﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AuthenticationService.Exceptions;
using AuthenticationService.Models;
using AuthenticationService.Repository;

namespace AuthenticationService.Service
{
    public class AuthService : IAuthService
    {
        private readonly IAuthRepository repository;

        public AuthService(IAuthRepository _repository)
        {
            this.repository = _repository;
        }

        public bool IsUserExist(User user)
        {
            User requiredUser;
            try
            {
                requiredUser = repository.FindUserById(user.UserId);
                return !ReferenceEquals(requiredUser, null);
            }
            catch
            {
                throw new Exception("Server Error");
            }
        }

        public User LoginUser(string userId, string password)
        {
            User createdUser;
            try
            {
                createdUser = repository.LoginUser(userId, password);
                if (ReferenceEquals(createdUser, null))
                {
                    throw new Exception();
                }
            }
            catch
            {
                throw new UserNotFoundException($"User with this id {userId} and password {password} does not exist");
            }
            return createdUser;
        }

        public bool RegisterUser(User user)
        {
            try
            {
                if (!repository.RegisterUser(user))
                {
                    throw new Exception();
                }
            }
            catch
            {
                throw new UserNotCreatedException($"User with this id {user.UserId} already exists");
            }
            return true;
        }
    }
}
