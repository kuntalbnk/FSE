﻿using System.Collections.Generic;
using System.Linq;
using MongoDB.Driver;
using NoteService.API.Models;

namespace NoteService.API.Repository
{
    public class UserRepository : IUserRepository
    {
        public readonly IUserContext context;

        public UserRepository(IUserContext dbContext)
        {
            context = dbContext;
        }

        public List<User> GetAllUser()
        {
            return context.Users.Find(_ => true).ToList();
        }

        public bool DeleteUser(string userId)
        {
            var result = context.Users.DeleteOne(i => i.UserId == userId);
            return result.IsAcknowledged && result.DeletedCount > 0;
        }

        public User GetUserById(string userId)
        {
            return context.Users.Find(i => i.UserId == userId).FirstOrDefault();
        }

        public User RegisterUser(User user)
        {
            context.Users.InsertOne(user);
            return user;
        }

        public bool UpdateUser(string userId, User user)
        {
            var result = context.Users.ReplaceOne(filter: c => c.UserId == userId, replacement: user);
            return result.IsAcknowledged && result.ModifiedCount > 0;
        }
    }
}
