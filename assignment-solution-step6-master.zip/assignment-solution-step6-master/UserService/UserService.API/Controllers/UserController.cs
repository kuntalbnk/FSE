﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NoteService.API.Models;
using NoteService.API.Service;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace NoteService.API.Controllers
{
    [Authorize]
    [ExceptionHandler]
    [LoggingAspect]
    [Route("api/[controller]")]
    public class UserController : Controller
    {
        private readonly IUserService service;

        public UserController(IUserService _service)
        {
            this.service = _service;
        }

        // GET: api/<controller>
        [HttpGet]
        public IActionResult Get()
        {
            return Ok(service.GetAllUser());
        }

        // GET api/<controller>/5
        [HttpGet("{id}")]
        public IActionResult Get(string id)
        {
            return Ok(service.GetUserById(id));
        }

        // POST api/<controller>
        [HttpPost]
        public IActionResult Post(User user)
        {
            return Created("", service.RegisterUser(user));
        }

        // PUT api/<controller>/5
        [HttpPut("{id}")]
        public IActionResult Put(string id, User user)
        {
            service.UpdateUser(id, user);
            return Ok(user);
        }

        // DELETE api/<controller>/5
        [HttpDelete("{id}")]
        public IActionResult Delete(string id)
        {
            return Ok(service.DeleteUser(id));
        }
    }
}
