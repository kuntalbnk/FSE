﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using NoteService.API.Exceptions;
using NoteService.API.Models;
using NoteService.API.Repository;

namespace NoteService.API.Service
{
    public class NoteService : INoteService
    {
        private readonly INoteRepository repository;

        public NoteService(INoteRepository noteRepository)
        {
            repository = noteRepository;
        }

        public NoteUser AddNote(string userId, Note note)
        {
            return repository.UpdateNote(note.Id, userId, note);
        }

        public NoteUser CreateNote(NoteUser noteUser)
        {
            var createdNoteUser = repository.CreateNote(noteUser);
            if (ReferenceEquals(createdNoteUser, null))
            {
                throw new NoteAlreadyExistsException($"Note with id {noteUser.Notes.FirstOrDefault().Id} is already exist");
            }
            else
            {
                return createdNoteUser;
            }
        }

        public bool DeleteNote(string userId, int noteId)
        {
            if (!repository.DeleteNote(userId, noteId))
            {
                throw new NoteNotFoundExeption($"Note with User Id {userId} and Note Id {noteId} is not found");
            }
            return true;
        }

        public List<Note> GetAllNotes(string userId)
        {
            return repository.FindByUserId(userId);
        }

        public Note GetNote(string userId, int noteId)
        {
            Note requiredNote;
            List<Note> notes = repository.FindByUserId(userId);
            if (notes.Count == 0)
            {
                throw new NoteNotFoundExeption($"Note with User Id {userId} and Note Id {noteId} is not found");
            }
            else
            {
                requiredNote = notes.Find(i => i.Id == noteId);
                if (ReferenceEquals(requiredNote, null))
                {
                    throw new NoteNotFoundExeption($"Note with User Id {userId} and Note Id {noteId} is not found");
                }
                else
                {
                    return requiredNote;
                }
            }
        }

        public NoteUser UpdateNote(int noteId, string userId, Note note)
        {
            return repository.UpdateNote(noteId, userId, note);
        }
    }
}
