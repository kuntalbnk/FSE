﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using NoteService.API.Exceptions;

namespace NoteService.API.Models
{
    public class NoteExceptionHandlerAttribute : ExceptionFilterAttribute
    {
        public override void OnException(ExceptionContext context)
        {
            var exceptionType = context.Exception.GetType();
            var exceptionMessage = context.Exception.Message;

            if (exceptionType == typeof(NoteAlreadyExistsException))
            {
                var result = new NotFoundObjectResult(exceptionMessage);
                context.Result = result;
            }
            else if (exceptionType == typeof(NoteNotFoundExeption))
            {
                var result = new NotFoundObjectResult(exceptionMessage);
                context.Result = result;
            }
            else
            {
                var result = new StatusCodeResult(500);
                context.Result = result;
            }
        }
    }
}
