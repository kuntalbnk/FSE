﻿using System;
using System.Collections.Generic;
using System.Linq;
using NoteService.API.Models;
using MongoDB.Driver;

namespace NoteService.API.Repository
{
    public class NoteRepository : INoteRepository
    {
        private readonly INoteContext context;
        public NoteRepository(INoteContext dbContext)
        {
            context = dbContext;
        }

        public NoteUser CreateNote(NoteUser noteUser)
        {
            context.Notes.InsertOne(noteUser);
            return noteUser;
        }

        public bool DeleteNote(string userId, int noteId)
        {
            var noteUserToModify = context.Notes.Find(i => i.UserId == userId).FirstOrDefault();
            var noteToDelete = noteUserToModify.Notes.Find(i => i.Id == noteId);
            bool status = noteUserToModify.Notes.Remove(noteToDelete);

            if (status)
            {
                var result = context.Notes.ReplaceOne(filter: i => i.UserId == userId, replacement: noteUserToModify);
                return result.IsAcknowledged;
            }
            else
            {
                return false;
            }
        }

        public List<Note> FindByUserId(string userId)
        {
            var noteUser = context.Notes.Find(i => i.UserId == userId).FirstOrDefault();
            if (ReferenceEquals(noteUser, null))
            {
                return null;
            }
            else
            {
                return noteUser.Notes;
            }
        }

        public NoteUser UpdateNote(int noteId, string userId, Note note)
        {
            NoteUser noteUserToModify = context.Notes.Find(i => i.UserId == userId).FirstOrDefault();
            var noteToModify = noteUserToModify.Notes.Find(i => i.Id == noteId);
            int indx = noteUserToModify.Notes.IndexOf(noteToModify);
            noteUserToModify.Notes[indx] = note;

            var result = context.Notes.ReplaceOne(filter: i => i.UserId == userId, replacement: noteUserToModify);
            return noteUserToModify;
        }
    }
}
