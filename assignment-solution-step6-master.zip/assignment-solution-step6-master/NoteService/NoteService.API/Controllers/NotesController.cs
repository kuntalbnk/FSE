﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NoteService.API.Models;
using NoteService.API.Service;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace NoteService.API.Controllers
{
    [Authorize]
    [NoteExceptionHandler]
    [NoteLoggingAspect]
    [Route("api/[controller]")]
    public class NotesController : Controller
    {
        private readonly INoteService service;

        public NotesController(INoteService _service)
        {
            this.service = _service;
        }

        // GET: api/<controller>
        [HttpGet]
        public IActionResult Get()
        {
            return Ok(null);
        }

        // GET api/<controller>/5
        [HttpGet("{userId}")]
        public IActionResult Get(string userId)
        {
            return Ok(service.GetAllNotes(userId));
        }

        // POST api/<controller>
        [HttpPost("{userId}")]
        public IActionResult Post(string userId, [FromBody]Note note)
        {
            return Ok(service.AddNote(userId, note).Notes);
        }

        // PUT api/<controller>/1/5
        [HttpPut("{id}/{userId}")]
        public IActionResult Put(int id, string userId, [FromBody]Note note)
        {
            return Ok(service.UpdateNote(id, userId, note));
        }

        // DELETE api/<controller>/5
        [HttpDelete("{userId}/{id}")]
        public IActionResult Delete(string userId, int id)
        {
            return Ok(service.DeleteNote(userId, id));
        }
    }
}
