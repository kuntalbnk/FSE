﻿using System;
using System.Collections.Generic;
using CategoryService.API.Models;
using CategoryService.API.Repository;
using CategoryService.API.Exceptions;
using MongoDB.Driver;

namespace CategoryService.API.Service
{
    public class CategoryService : ICategoryService
    {
        private readonly ICategoryRepository repository;

        public CategoryService(ICategoryRepository categoryRepository)
        {
            repository = categoryRepository;
        }

        public Category CreateCategory(Category category)
        {
            Category createdCategory;
            try
            {
                createdCategory = repository.CreateCategory(category);
                if (ReferenceEquals(createdCategory, null))
                {
                    throw new Exception();
                }
            }
            catch
            {
                throw new CategoryNotCreatedException("This category id already exists");
            }

            return createdCategory;
        }

        public bool DeleteCategory(int categoryId)
        {
            try
            {
                if (repository.DeleteCategory(categoryId))
                {
                    return true;
                }
                else
                {
                    throw new Exception();
                }
            }
            catch
            {
                throw new CategoryNotFoundException("This category id not found");
            }
        }

        public List<Category> GetAllCategoriesByUserId(string userId)
        {
            return repository.GetAllCategoriesByUserId(userId);
        }

        public Category GetCategoryById(int categoryId)
        {
            Category category;
            try
            {
                category = repository.GetCategoryById(categoryId);
                if (ReferenceEquals(category, null))
                {
                    throw new Exception();
                }
            }
            catch
            {
                throw new CategoryNotFoundException("This category id not found");
            }
            return category;
        }

        public bool UpdateCategory(int categoryId, Category category)
        {
            try
            {
                if (repository.UpdateCategory(categoryId, category))
                {
                    return true;
                }
                else
                {
                    throw new Exception();
                }
            }
            catch
            {
                throw new CategoryNotFoundException("This category id not found");
            }
        }
    }
}
