﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GoogleKeep.Models
{
    public class NoteList
    {
        public List<Note> GetInitialNoteList()
        {
            return GetDummyNotes();
        }

        private List<Note> GetDummyNotes()
        {
            List<Note> notes = new List<Note>();
            notes.Add(new Note()
            {
                NoteId = 1,
                Title = "JIRA ticket no. PLS-34335",
                Labels = new List<Label>()
                {
                    new Label()
                    {
                        LabelId = 1,
                        labelText = "Requirement Analysis & Design",
                        NoteId = 1
                    },
                    new Label()
                    {
                        LabelId = 2,
                        labelText = "Coding & Unit Testing",
                        NoteId = 1
                    },
                    new Label()
                    {
                        LabelId = 3,
                        labelText = "QAT Testing",
                        NoteId = 1
                    },
                    new Label()
                    {
                        LabelId = 4,
                        labelText = "SIT Testing & Production",
                        NoteId = 1
                    },
                    new Label()
                    {
                        LabelId = 5,
                        labelText = "Production Release",
                        NoteId = 1
                    }
                },
                Checklists = new List<Checklist>()
                {
                    new Checklist()
                    {
                        ChecklistId = 1,
                        ChecklistText = "DDD Preparation",
                        NoteId = 1
                    },
                    new Checklist()
                    {
                        ChecklistId = 2,
                        ChecklistText = "UTC Preparation",
                        NoteId = 1
                    },
                    new Checklist()
                    {
                        ChecklistId = 3,
                        ChecklistText = "RTM Preparation",
                        NoteId = 1
                    },
                    new Checklist()
                    {
                        ChecklistId = 4,
                        ChecklistText = "RCA Preparation",
                        NoteId = 1
                    }
                }
            });
            return notes;
        }
    }
}
