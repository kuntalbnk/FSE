﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GoogleKeep.Models
{
    public class Checklist
    {
        public int ChecklistId { get; set; }
        public string ChecklistText { get; set; }
        public int NoteId { get; set; }
    }
}
