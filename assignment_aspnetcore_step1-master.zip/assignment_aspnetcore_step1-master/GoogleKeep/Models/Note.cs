﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GoogleKeep.Models
{
    public class Note
    {
        public int NoteId { get; set; }
        public string Title { get; set; }
        public List<Label> Labels { get; set; }
        public List<Checklist> Checklists { get; set; }
    }
}
