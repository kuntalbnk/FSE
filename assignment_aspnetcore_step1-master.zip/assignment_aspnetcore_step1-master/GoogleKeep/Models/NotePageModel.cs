﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GoogleKeep.Models
{
    public class NotePageModel
    {
        public List<Note> Notes { get; set; }
        public string ChecklistText { get; set; }
        public string LabelText { get; set; }
    }
}
