﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GoogleKeep.Models
{
    public class Label
    {
        public int LabelId { get; set; }
        public string labelText { get; set; }
        public int NoteId { get; set; }
    }
}
