﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GoogleKeep.Models;
using GoogleKeep.Utility;
using Microsoft.AspNetCore.Mvc;

namespace GoogleKeep.Controllers
{
    public class NoteController : Controller
    {
        NotePageModel notePageModel;
        public IActionResult Index()
        {
            notePageModel = new NotePageModel();

            notePageModel.Notes = GetNotes();

            return View(notePageModel);
        }

        public IActionResult AddNote()
        {
            ViewData["Title"] = "Add New Note";
            notePageModel = new NotePageModel();
            List<Note> Notes = new List<Note>();
            int maxNoteId = 0;

            // Get Existing data
            NoteList objNoteList = new NoteList();
            Notes = GetNotes();

            // New Note, Create a note and add to main object
            if (Notes.Count > 0)
                maxNoteId = Notes.Last().NoteId;
            Note newNote = new Note()
            {
                NoteId = maxNoteId + 1,
                Title = string.Empty,
                Labels = new List<Label>(),
                Checklists = new List<Checklist>()
            };
            Notes.Add(newNote);

            notePageModel.Notes = Notes.FindAll(i => i.NoteId == newNote.NoteId);

            // Update TempData
            TempData.Put("GoogleKeepClone_Notes", Notes);
            TempData.Keep();

            return View("NoteForm", notePageModel);
        }

        public IActionResult EditNote(int Id)
        {
            ViewData["Title"] = "Edit Note";
            notePageModel = new NotePageModel();
            NoteList objNoteList = new NoteList();

            notePageModel.Notes = GetNotes().FindAll(i => i.NoteId == Id);

            return View("NoteForm", notePageModel);
        }

        public IActionResult Save(NotePageModel Model, string AddChecklist, string DeleteChecklist, string AddLabel, string DeleteLabel, string SaveNote, string DeleteNote)
        {
            ViewData["Title"] = "Note";
            List<Note> Notes = new List<Note>();
            notePageModel = new NotePageModel();
            int maxChecklistId = 0;
            int maxLabelId = 0;
            Checklist checklistToRemove = new Checklist();
            Label labelToRemove = new Label();
            int noteId = Model.Notes[0].NoteId;

            // Get Existing data
            Notes = GetNotes();

            // Update Note property
            Notes.Find(i => i.NoteId == noteId).Title = Model.Notes[0].Title;

            // Check appropriate action and modify model accordingly
            // Add Checklist
            if (!String.IsNullOrWhiteSpace(AddChecklist))
            {
                foreach (Note note in Notes)
                {
                    if (note.Checklists.Count > 0)
                        maxChecklistId = note.Checklists.Last().ChecklistId > maxChecklistId ? note.Checklists.Last().ChecklistId : maxChecklistId;
                }

                Notes.Find(i => i.NoteId == noteId)
                    .Checklists
                    .Add(new Checklist()
                    {
                        ChecklistId = maxChecklistId + 1,
                        ChecklistText = Model.ChecklistText,
                        NoteId = noteId
                    });
            }

            // Delete Checklist
            else if (!String.IsNullOrWhiteSpace(DeleteChecklist))
            {
                checklistToRemove = Notes.SelectMany(i => i.Checklists).SingleOrDefault(i => i.ChecklistId == Convert.ToInt32(DeleteChecklist));
                if (!ReferenceEquals(checklistToRemove, null))
                {
                    Notes.All(i => i.Checklists.Remove(checklistToRemove));
                }
            }

            // Add label
            else if (!String.IsNullOrWhiteSpace(AddLabel))
            {
                foreach (Note note in Notes)
                {
                    if (note.Labels.Count > 0)
                        maxLabelId = note.Labels.Last().LabelId > maxLabelId ? note.Labels.Last().LabelId : maxLabelId;
                }

                Notes.Find(i => i.NoteId == noteId)
                    .Labels
                    .Add(new Label()
                    {
                        LabelId = maxLabelId + 1,
                        labelText = Model.LabelText,
                        NoteId = noteId
                    });
            }

            // Delete Label
            else if (!String.IsNullOrWhiteSpace(DeleteLabel))
            {
                labelToRemove = Notes.SelectMany(i => i.Labels).SingleOrDefault(i => i.LabelId == Convert.ToInt32(DeleteLabel));
                if (!ReferenceEquals(labelToRemove, null))
                {
                    Notes.All(i => i.Labels.Remove(labelToRemove));
                }
            }

            // Delete note
            else if (!String.IsNullOrWhiteSpace(DeleteNote))
            {
                Notes.Remove(Notes.SingleOrDefault(i => i.NoteId == noteId));
            }

            // Update TempData
            TempData.Put("GoogleKeepClone_Notes", Notes);
            TempData.Keep();

            // Save entire note
            if (!String.IsNullOrWhiteSpace(SaveNote))
            {
                notePageModel.Notes = GetNotes();
                return View("Index", notePageModel);
            }

            // Delete note
            else if (!String.IsNullOrWhiteSpace(DeleteNote))
            {
                notePageModel.Notes = GetNotes();
                return View("Index", notePageModel);
            }

            // Update PageModel with latest data
            notePageModel.Notes = Notes.FindAll(i => i.NoteId == noteId);
            notePageModel.ChecklistText = Model.ChecklistText;
            notePageModel.LabelText = Model.LabelText;
            if (!String.IsNullOrWhiteSpace(AddChecklist))
            {
                notePageModel.ChecklistText = null;
            }
            else if (!String.IsNullOrWhiteSpace(AddLabel))
            {
                notePageModel.LabelText = null;
            }

            ModelState.Clear();
            return View("NoteForm", notePageModel);
        }

        private List<Note> GetNotes()
        {
            List<Note> Notes = new List<Note>();
            NoteList objNoteList = new NoteList();

            if (ReferenceEquals(TempData.Get<List<Note>>("GoogleKeepClone_Notes"), null))
            {
                TempData.Put("GoogleKeepClone_Notes", objNoteList.GetInitialNoteList());
            }
            Notes = TempData.Get<List<Note>>("GoogleKeepClone_Notes");
            TempData.Keep();

            return Notes;
        }
    }
}