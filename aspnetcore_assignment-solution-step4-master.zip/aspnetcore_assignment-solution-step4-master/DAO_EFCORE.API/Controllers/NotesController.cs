﻿using System;
using System.Collections.Generic;
using System.Net;
using DAO_EFCORE.Business;
using DAO_EFCORE.Business.Exceptions;
using DAO_EFCORE.DAL.Models;
using DAO_EFCORE.API.Utility;
using Microsoft.AspNetCore.Mvc;

namespace DAO_EFCORE.API.Controllers
{
    [ExceptionHandler]
    [Logger]
    [Route("api/[controller]")]
    public class NotesController : Controller
    {
        private INoteService service;

        public NotesController(INoteService noteService)
        {
            service = noteService;
        }

        //implementation of all required routes

        [HttpGet]
        public IActionResult Get()
        {
            List<Note> notes = new List<Note>();
            notes = service.GetAllNotes();
            return new OkObjectResult(notes);
        }

        [Route("{id}")]
        [HttpGet]
        public IActionResult Get(int id)
        {
            Note note = new Note();
            note = service.GetNote(id);
            return new OkObjectResult(note);
        }

        [HttpPost]
        public IActionResult Post(Note note)
        {
            Note addedNote = new Note();
            addedNote = service.AddNote(note);
            return new CreatedResult("api/notes", addedNote);
        }

        [Route("{id}")]
        [HttpDelete]
        public IActionResult Delete(int id)
        {
            bool status = false;
            status = service.RemoveNote(id);
            return new OkObjectResult(status);
        }

        [Route("{id}/labels")]
        [HttpPost]
        public IActionResult AddLabel(int id, Label label)
        {
            Label addedLabel = new Label();
            addedLabel = service.AddLabel(id, label);
            return new CreatedResult("api/notes/{id}/labels", addedLabel);
        }

        [Route("{id}/labels/{labelId}")]
        [HttpDelete]
        public IActionResult RemoveLabel(int id, int labelId)
        {
            bool status = false;
            status = service.RemoveLabel(id, labelId);
            return new OkObjectResult(status);
        }

        [Route("{id}/labels/{labelId}")]
        [HttpPut]
        public IActionResult UpdateLabel(int id, int labelId, Label label)
        {
            bool status = false;
            status = service.UpdateLabel(id, label);
            return new OkObjectResult(status);
        }

        [Route("{id}/checklist")]
        [HttpPost]
        public IActionResult AddChecklist(int id, Checklist checklist)
        {
            Checklist addedChecklist = new Checklist();
            addedChecklist = service.AddChecklist(id, checklist);
            return new CreatedResult("api/notes/{id}/checklist", addedChecklist);
        }

        [Route("{id}/checklist/{itemId}")]
        [HttpDelete]
        public IActionResult RemoveChecklist(int id, int itemId)
        {
            bool status = false;
            status = service.RemoveChecklist(id, itemId);
            return new OkObjectResult(status);
        }

        [Route("{id}/checklist/{itemId}")]
        [HttpPut]
        public IActionResult UpdateChecklist(int id, int itemId, Checklist checklist)
        {
            bool status = false;
            status = service.UpdateChecklist(id, checklist);
            return new OkObjectResult(status);
        }

        [Route("getbylabel/{lblText}")]
        [HttpGet]
        public IActionResult GetNotesByLabel(string lblText)
        {
            List<Note> notes = new List<Note>();
            notes = service.GetNotesByLabel(lblText);
            return new OkObjectResult(notes);
        }

        [Route("getbytitle/{title}")]
        [HttpGet]
        public IActionResult GetNotesByTitle(string title)
        {
            List<Note> notes = new List<Note>();
            notes = service.GetNotesByTitle(title);
            return new OkObjectResult(notes);
        }
    }
}
