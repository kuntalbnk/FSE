﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DAO_EFCORE.DAL.Models;
using Microsoft.EntityFrameworkCore;

namespace DAO_EFCORE.DAL.Persistence
{
    public class NoteRepository : INoteRepository
    {
        private IKeepNoteContext context;

        public NoteRepository(IKeepNoteContext dbContext)
        {
            context = dbContext;
        }

        public Checklist AddChecklist(Checklist checklist)
        {
            try
            {
                context.Checklists.Add(checklist);
                if (context.SaveChanges() == 0)
                    checklist = new Checklist();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return checklist;
        }

        public Label AddLabel(Label label)
        {
            try
            {
                context.Labels.Add(label);
                if (context.SaveChanges() == 0)
                    label = new Label();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return label;
        }

        public Note AddNote(Note note)
        {
            try
            {
                context.Notes.Add(note);
                if (context.SaveChanges() == 0)
                    note = new Note();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return note;
        }

        public List<Checklist> GetAllCheckListItems(int noteId)
        {
            return context.Checklists.Where(i => i.Note.NoteId == noteId).ToList();
        }

        public List<Label> GetAllLabels(int noteId)
        {
            return context.Labels.Where(i => i.Note.NoteId == noteId).ToList();
        }

        public List<Note> GetAllNotes()
        {
            return context.Notes.ToList();
        }

        public List<Note> GetAllNotesByLabel(string lblText)
        {
            return context.Notes.Where(i => i.Labels.FirstOrDefault(l => l.Content == lblText).NoteId == i.NoteId).ToList();
        }

        public List<Note> GetAllNotesByTitle(string title)
        {
            return context.Notes.Where(i => i.Title == title).ToList();
        }

        public Label GetLabel(int labelId)
        {
            return context.Labels.Find(labelId);
        }

        public Note GetNote(int noteId)
        {
            return context.Notes.Find(noteId);
        }

        public bool RemoveChecklist(int id)
        {
            var checklistToRemove = context.Checklists.Find(id);
            context.Checklists.Remove(checklistToRemove);
            int rowsAffected = context.SaveChanges();
            return rowsAffected > 0;
        }

        public bool RemoveLabel(int id)
        {
            var labelToRemove = context.Labels.Find(id);
            context.Labels.Remove(labelToRemove);
            int rowsAffected = context.SaveChanges();
            return rowsAffected > 0;
        }

        public bool RemoveNote(int id)
        {
            var noteToRemove = context.Notes.Find(id);
            context.Notes.Remove(noteToRemove);
            int rowsAffected = context.SaveChanges();
            return rowsAffected > 0;
        }

        public bool UpdateChecklist(Checklist checklist)
        {
            var checklistToUpdate = context.Checklists.Find(checklist.ChecklistId);
            checklistToUpdate.Content = checklist.Content;
            int rowsAffected = context.SaveChanges();
            return rowsAffected > 0;
        }

        public bool UpdateLabel(Label label)
        {
            var labelToUpdate = context.Labels.Find(label.LabelId);
            labelToUpdate.Content = label.Content;
            int rowsAffected = context.SaveChanges();
            return rowsAffected > 0;
        }
    }
}
