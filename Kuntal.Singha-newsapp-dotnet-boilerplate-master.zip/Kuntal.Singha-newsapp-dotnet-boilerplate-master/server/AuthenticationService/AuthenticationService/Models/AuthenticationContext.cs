﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace AuthenticationService.Models
{
    public class AuthenticationContext : DbContext, IAuthenticationContext
    {
        public AuthenticationContext() { }
        public AuthenticationContext(DbContextOptions<AuthenticationContext> options) : base(options)
        {
            Database.EnsureCreated();
        }
        public DbSet<User> Users { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            var news_table = modelBuilder.Entity<User>();
            news_table
                .ToTable("Users");
            news_table
                .HasKey(n => n.UserId);
            news_table
                .Property(n => n.Password)
                .IsRequired();
            news_table
                .Property(n => n.FirstName)
                .IsRequired();
            news_table
                .Property(n => n.LastName)
                .IsRequired();
            news_table
                .Property(n => n.Role)
                .IsRequired();
            news_table
                .Property(n => n.AddedDate)
                .HasColumnType("DateTime");

        }
    }
}
