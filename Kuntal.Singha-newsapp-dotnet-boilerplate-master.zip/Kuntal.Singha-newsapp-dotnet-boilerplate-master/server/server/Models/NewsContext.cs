﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace server.Models
{
    public class NewsContext : DbContext, INewsContext
    {
        public NewsContext() { }
        public NewsContext(DbContextOptions<NewsContext> options) : base(options)
        {
            Database.EnsureCreated();
        }
        public DbSet<News> News { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            var news_table = modelBuilder.Entity<News>();
            news_table
                .ToTable("News");
            news_table
                .HasKey(n => n.NewsId);
            news_table
                .Property(n => n.NewsId)
                .ValueGeneratedOnAdd();
            news_table
                .Property(n => n.Title)
                .IsRequired();
            news_table
                .Property(n => n.Description)
                .IsRequired();
            news_table
                .Property(n => n.UrlToImage)
                .IsRequired();
            news_table
                .Property(n => n.Url)
                .IsRequired();
            news_table
                .Property(n => n.Content)
                .IsRequired();
            news_table
                .Property(n => n.UserId);
            news_table
                .Ignore(n => n.AddedToFavourite);

        }
    }
}
