﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace server.Models
{
    public class Response
    {
        public string Status { get; set; }
        public int TotalResults { get; set; }
        public List<News> Articles { get; set; }
    }
}
