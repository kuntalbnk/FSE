﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using server.Models;
using server.Service;

namespace server.Controllers
{
    [Authorize]
    [ExceptionHandler]
    [LoggingAspect]
    [Route("api/[controller]")]
    public class NewsController : Controller
    {
        private readonly INewsService service;

        public NewsController(INewsService _service)
        {
            service = _service;
        }

        // GET: api/news
        [HttpGet]
        public IActionResult Get()
        {
            return Ok("News Service is up & running");
        }

        // GET: api/news/category
        [HttpGet("{category}/{userid}")]
        public async Task<IActionResult> Get(string category, string userid)
        {
            return Ok(await service.GetNewsCategoryWise(category, userid));
        }

        // GET: api/news/top_heading
        [HttpGet("top_heading/{userid}")]
        public async Task<IActionResult> GetTopHeading(string userid)
        {
            return Ok(await service.GetTopHeading(userid));
        }

        // GET: api/news/top_heading
        [HttpGet("search_news/{q}/{userid}")]
        public async Task<IActionResult> SearchNews(string q, string userid)
        {
            return Ok(await service.SearchNews(q, userid));
        }

        // GET: api/news/top_heading
        [HttpGet("favourite/{userid}")]
        public IActionResult GetAllFavourite(string userid)
        {
            return Ok(service.GetAllFavourite(userid));
        }

        // POST: api/news
        [HttpPost("add_to_favourite")]
        public IActionResult Post([FromBody]News news)
        {
            return Created("", service.AddToFavourite(news));
        }

        // DELETE: api/news
        [HttpPost("remove_from_favourite")]
        public IActionResult Delete([FromBody]News news)
        {
            return Ok(service.RemoveFromFavourite(news));
        }
    }
}
