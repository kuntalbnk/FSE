﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace server.Exceptions
{
    public class ApiNotFoundException : ApplicationException
    {
        public ApiNotFoundException() { }
        public ApiNotFoundException(string message) : base(message) { }
    }
}
