﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace server.Exceptions
{
    public class DuplicateNewsException : ApplicationException
    {
        public DuplicateNewsException() { }
        public DuplicateNewsException(string message) : base(message) { }
    }
}
