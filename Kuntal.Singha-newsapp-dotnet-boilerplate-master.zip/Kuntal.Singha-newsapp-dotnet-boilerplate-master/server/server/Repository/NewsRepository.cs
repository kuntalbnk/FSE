﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using server.Models;

namespace server.Repository
{
    public class NewsRepository : INewsRepository
    {
        public readonly INewsContext context;

        public NewsRepository(INewsContext newsContext)
        {
            context = newsContext;
        }

        public List<News> GetAllFavourite(string userid)
        {
            try
            {
                return context.News.Where(i => i.UserId == userid).ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool AddToFavourite(News news)
        {
            try
            {
                context.News.Add(news);
                return context.SaveChanges() > 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool RemoveFromFavourite(News news)
        {
            try
            {
                News newsToBeRemoved;
                newsToBeRemoved = context.News.FirstOrDefault(i => i.Title == news.Title && i.UserId == news.UserId);
                if (ReferenceEquals(newsToBeRemoved, null))
                {
                    return false;
                }
                else
                {
                    context.News.Remove(newsToBeRemoved);
                    return context.SaveChanges() > 0;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
