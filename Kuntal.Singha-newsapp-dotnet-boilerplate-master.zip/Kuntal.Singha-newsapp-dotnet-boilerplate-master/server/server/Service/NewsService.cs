﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using server.Exceptions;
using server.Models;
using server.Repository;

namespace server.Service
{
    public class NewsService : INewsService
    {
        public readonly INewsRepository repository;
        public readonly IConfiguration configuration;

        private readonly string baseUrl;
        private readonly string urlToken;

        public NewsService(INewsRepository newsRepository, IConfiguration _configuration)
        {
            repository = newsRepository;
            if (!ReferenceEquals(_configuration, null))
            {
                configuration = _configuration;
                baseUrl = configuration["BaseURL"];
                urlToken = configuration["Token"];
            }
        }

        public async Task<List<News>> GetNewsCategoryWise(string category, string userid)
        {
            using (var client = new HttpClient())
            {
                try
                {
                    client.BaseAddress = new Uri(baseUrl);
                    var response = await client.GetAsync($"top-headlines?category={category}&apikey={urlToken}&page=1");
                    response.EnsureSuccessStatusCode();

                    var data = JsonConvert.DeserializeObject<Response>(await response.Content.ReadAsStringAsync());
                    return CheckFavouriteAndUpdateNewsList(data.Articles, userid);
                }
                catch (HttpRequestException ex)
                {
                    throw new ApiNotFoundException(ex.Message);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }

        public async Task<List<News>> GetTopHeading(string userid)
        {
            using (var client = new HttpClient())
            {
                try
                {
                    client.BaseAddress = new Uri(baseUrl);
                    var response = await client.GetAsync($"top-headlines?country=in&apikey={urlToken}&page=1");
                    response.EnsureSuccessStatusCode();

                    var data = JsonConvert.DeserializeObject<Response>(await response.Content.ReadAsStringAsync());
                    return CheckFavouriteAndUpdateNewsList(data.Articles, userid);
                }
                catch (HttpRequestException ex)
                {
                    throw new ApiNotFoundException(ex.Message);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }

        public async Task<List<News>> SearchNews(string key, string userid)
        {
            using (var client = new HttpClient())
            {
                try
                {
                    client.BaseAddress = new Uri(baseUrl);
                    var response = await client.GetAsync($"everything?q={key}&apikey={urlToken}&language=en&page=1");
                    response.EnsureSuccessStatusCode();

                    var data = JsonConvert.DeserializeObject<Response>(await response.Content.ReadAsStringAsync());
                    return CheckFavouriteAndUpdateNewsList(data.Articles, userid);
                }
                catch (HttpRequestException ex)
                {
                    throw new ApiNotFoundException(ex.Message);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }

        public List<News> GetAllFavourite(string userid)
        {
            try
            {
                List<News> newsList = repository.GetAllFavourite(userid);
                newsList.ForEach(i =>
                {
                    i.AddedToFavourite = true;
                });
                return newsList;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool AddToFavourite(News news)
        {
            bool output;
            try
            {
                if (repository.GetAllFavourite(news.UserId).Any(i => i.Title == news.Title))
                {
                    throw new DuplicateNewsException($"A news with the title {news.Title} already exsist");
                }
                else
                {
                    output = repository.AddToFavourite(news);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return output;
        }

        public bool RemoveFromFavourite(News news)
        {
            bool output;
            try
            {
                output = repository.RemoveFromFavourite(news);
                if (!output)
                {
                    throw new NewsNotFoundException($"A news with the title {news.Title} does not exist");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return output;
        }

        private List<News> CheckFavouriteAndUpdateNewsList(List<News> articles, string userid)
        {
            try
            {
                List<News> favouriteNews = repository.GetAllFavourite(userid);
                if (!ReferenceEquals(favouriteNews, null) && favouriteNews.Count > 0)
                {
                    favouriteNews.ForEach(n =>
                    {
                        if (articles.Any(i => i.Title == n.Title))
                        {
                            articles.Find(i => i.Title == n.Title).AddedToFavourite = true;
                        }
                    });
                }
                // Refine Image Link
                WebRequest request;
                articles.ForEach(a =>
                {
                    bool exist = true;
                    if (string.IsNullOrWhiteSpace(a.UrlToImage))
                    {
                        a.UrlToImage = "https://i.stack.imgur.com/GNhxO.png";
                    }
                    else
                    {
                        request = WebRequest.Create(a.UrlToImage);

                        try
                        {
                            request.GetResponse();
                            exist = true;
                        }
                        catch
                        {
                            exist = false;
                        }

                        if (!exist)
                        {
                            a.UrlToImage = "https://i.stack.imgur.com/GNhxO.png";
                        }
                    }
                    a.UserId = userid;
                });
                return articles;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
