﻿using server.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace server.Service
{
    public interface INewsService
    {
        bool AddToFavourite(News news);
        bool RemoveFromFavourite(News news);
        Task<List<News>> GetNewsCategoryWise(string category, string userid);
        Task<List<News>> GetTopHeading(string userid);
        Task<List<News>> SearchNews(string key, string userid);
        List<News> GetAllFavourite(string userid);
    }
}
