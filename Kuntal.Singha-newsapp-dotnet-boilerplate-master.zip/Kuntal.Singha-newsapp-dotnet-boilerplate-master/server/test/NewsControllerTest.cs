﻿using Microsoft.AspNetCore.Mvc;
using Moq;
using server.Controllers;
using server.Models;
using server.Service;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace test
{
    public class NewsControllerTest
    {
        [Fact]
        public void POSTShouldReturnCreated()
        {
            var mockService = new Mock<INewsService>();
            News news = new News
            {
                NewsId = 2,
                Title = "Test Title 2",
                Description = "This is News description",
                Content = "This is News content",
                UrlToImage = "http://www.google.com/google.png",
                Url = "http://www.google.com",
                UserId = "123456",
                AddedToFavourite = true
            };

            mockService.Setup(service => service.AddToFavourite(news)).Returns(true);
            var newsController = new NewsController(mockService.Object);

            var actual = newsController.Post(news);

            var actionReult = Assert.IsType<CreatedResult>(actual);
            var actualValue = actionReult.Value;
            var expected = true;
            Assert.Equal(expected, actualValue);
        }

        [Fact]
        public void GetShouldReturnListOfFavouriteNews()
        {
            var mockService = new Mock<INewsService>();
            mockService.Setup(service => service.GetAllFavourite("123456")).Returns(GetNews());
            var newsController = new NewsController(mockService.Object);

            var actual = newsController.GetAllFavourite("123456");

            var actionReult = Assert.IsType<OkObjectResult>(actual);
            Assert.IsAssignableFrom<List<News>>(actionReult.Value);
        }

        [Fact]
        public void DeleteShouldReturnOK()
        {
            var mockService = new Mock<INewsService>();
            News news = new News
            {
                NewsId = 1,
                Title = "Test Title",
                Description = "This is News description",
                Content = "This is News content",
                UrlToImage = "http://www.google.com/google.png",
                Url = "http://www.google.com",
                UserId = "123456",
                AddedToFavourite = true
            };
            mockService.Setup(service => service.RemoveFromFavourite(news)).Returns(true);
            var newsController = new NewsController(mockService.Object);

            var actual = newsController.Delete(news);

            var actionReult = Assert.IsType<OkObjectResult>(actual);
            var actualValue = actionReult.Value;
            var expected = true;
            Assert.Equal(expected, actualValue);
        }

        [Fact]
        public void GetTopHeadingShouldReturnListOfNews()
        {
            var mockService = new Mock<INewsService>();
            mockService.Setup(service => service.GetTopHeading("123456")).Returns(GetNewsTask());
            var newsController = new NewsController(mockService.Object);
            var actual = newsController.GetTopHeading("123456");
            actual.Wait();
            var actionReult = Assert.IsType<OkObjectResult>(actual.Result);
        }

        [Fact]
        public void GetShouldReturnListOfNewsCatigorise()
        {
            var mockService = new Mock<INewsService>();
            mockService.Setup(service => service.GetNewsCategoryWise("business", "123456")).Returns(GetNewsTask());
            var newsController = new NewsController(mockService.Object);
            var actual = newsController.Get("business", "123456");
            actual.Wait();
            var actionReult = Assert.IsType<OkObjectResult>(actual.Result);
        }

        [Fact]
        public void SearchNewsShouldReturnListOfNews()
        {
            var mockService = new Mock<INewsService>();
            mockService.Setup(service => service.SearchNews("dot net", "123456")).Returns(GetNewsTask());
            var newsController = new NewsController(mockService.Object);
            var actual = newsController.SearchNews("dot net", "123456");
            actual.Wait();
            var actionReult = Assert.IsType<OkObjectResult>(actual.Result);
        }

        private List<News> GetNews()
        {
            List<News> news = new List<News>
            {
                new News
                {
                    NewsId = 1,
                    Title = "Test Title",
                    Description = "This is News description",
                    Content = "This is News content",
                    UrlToImage = "http://www.google.com/google.png",
                    Url = "http://www.google.com",
                    UserId = "123456",
                    AddedToFavourite = true
                },
            };

            return news;
        }

        private Task<List<News>> GetNewsTask()
        {
            List<News> news = new List<News>
            {
                new News
                {
                    NewsId = 1,
                    Title = "Test Title",
                    Description = "This is News description",
                    Content = "This is News content",
                    UrlToImage = "http://www.google.com/google.png",
                    Url = "http://www.google.com",
                    UserId = "123456",
                    AddedToFavourite = true
                }
            };
            var newsList = new TaskCompletionSource<List<News>>();
            newsList.SetResult(news);

            return newsList.Task;
        }
    }
}
