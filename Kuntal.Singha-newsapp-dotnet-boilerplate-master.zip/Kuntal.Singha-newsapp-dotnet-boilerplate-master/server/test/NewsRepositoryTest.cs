﻿using server.Models;
using server.Repository;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace test
{
    public class NewsRepositoryTest : IClassFixture<DatabaseFixture>
    {
        private readonly DatabaseFixture fixture;
        private readonly INewsRepository newsRepo;

        public NewsRepositoryTest(DatabaseFixture _fixture)
        {
            this.fixture = _fixture;
            newsRepo = new NewsRepository(fixture.context);
        }

        [Fact]
        public void AddToFavouriteShouldReturnTrue()
        {
            News news = new News
            {
                NewsId = 2,
                Title = "Test Title 2",
                Description = "This is News description",
                Content = "This is News content",
                UrlToImage = "http://www.google.com/google.png",
                Url = "http://www.google.com",
                UserId = "123456",
                AddedToFavourite = true
            };
            var actual = newsRepo.AddToFavourite(news);
            Assert.True(actual);
        }

        [Fact]
        public void RemoveFromFavouriteShouldReturnTrue()
        {
            News news = new News
            {
                NewsId = 1,
                Title = "Test Title",
                Description = "This is News description",
                Content = "This is News content",
                UrlToImage = "http://www.google.com/google.png",
                Url = "http://www.google.com",
                UserId = "123456",
                AddedToFavourite = true
            };
            var actual = newsRepo.RemoveFromFavourite(news);
            Assert.True(actual);
        }

        [Fact]
        public void GetAllFavouriteShouldReturnNewsCollection()
        {
            var actual = newsRepo.GetAllFavourite("123456");
            Assert.IsAssignableFrom<List<News>>(actual);
            Assert.NotEmpty(actual);
        }
    }
}
