﻿using Microsoft.EntityFrameworkCore;
using System;
using server.Models;
using Xunit;

namespace test
{
    public class DatabaseFixture : IDisposable
    {
        public INewsContext context;

        public DatabaseFixture()
        {
            var options = new DbContextOptionsBuilder<NewsContext>()
                .UseInMemoryDatabase(databaseName: "News_Test_DB")
                .Options;

            //Initializing DbContext with InMemory
            context = new NewsContext(options);

            // Insert seed data into the database using one instance of the context
            context.News.Add(new News
            {
                NewsId = 1,
                Title = "Test Title",
                Description = "This is News description",
                Content = "This is News content",
                UrlToImage = "http://www.google.com/google.png",
                Url = "http://www.google.com",
                UserId = "123456",
                AddedToFavourite = true
            });
            context.SaveChanges();
        }
        public void Dispose()
        {
            context = null;
        }
    }
}