﻿using Castle.Core.Configuration;
using Moq;
using server.Exceptions;
using server.Models;
using server.Repository;
using server.Service;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace SBANewsApp.Test
{
    public class NewsServiceTest
    {
        [Fact]
        public void AddToFavouriteShouldReturnTrue()
        {
            var mockRepo = new Mock<INewsRepository>();
            News news = new News
            {
                NewsId = 2,
                Title = "Test Title 2",
                Description = "This is News description",
                Content = "This is News content",
                UrlToImage = "http://www.google.com/google.png",
                Url = "http://www.google.com",
                UserId = "123456",
                AddedToFavourite = true
            };
            mockRepo.Setup(repo => repo.GetAllFavourite("123456")).Returns(GetAllNews());
            mockRepo.Setup(repo => repo.AddToFavourite(news)).Returns(true);
            var service = new NewsService(mockRepo.Object, null);
            var actual = service.AddToFavourite(news);
            Assert.True(actual);
        }

        [Fact]
        public void GetAllFavouriteShouldReturnListOfNews()
        {
            var mockRepo = new Mock<INewsRepository>();
            mockRepo.Setup(repo => repo.GetAllFavourite("123456")).Returns(GetAllNews());
            var service = new NewsService(mockRepo.Object, null);

            var actual = service.GetAllFavourite("123456");

            Assert.IsAssignableFrom<List<News>>(actual);
        }

        [Fact]
        public void RemoveFromFavouriteShouldReturnTrue()
        {
            var mockRepo = new Mock<INewsRepository>();
            News news = new News
            {
                NewsId = 1,
                Title = "Test Title",
                Description = "This is News description",
                Content = "This is News content",
                UrlToImage = "http://www.google.com/google.png",
                Url = "http://www.google.com",
                UserId = "123456",
                AddedToFavourite = true
            };

            mockRepo.Setup(repo => repo.RemoveFromFavourite(news)).Returns(true);
            var service = new NewsService(mockRepo.Object, null);
            var actual = service.RemoveFromFavourite(news);
            Assert.True(actual);
        }

        [Fact]
        public void AddToFavouriteShouldThrowException()
        {
            var mockRepo = new Mock<INewsRepository>();
            News news = new News
            {
                NewsId = 1,
                Title = "Test Title",
                Description = "This is News description",
                Content = "This is News content",
                UrlToImage = "http://www.google.com/google.png",
                Url = "http://www.google.com",
                UserId = "123456",
                AddedToFavourite = true
            };
            mockRepo.Setup(repo => repo.GetAllFavourite("123456")).Returns(GetAllNews());
            mockRepo.Setup(repo => repo.AddToFavourite(news)).Returns(false);
            var service = new NewsService(mockRepo.Object, null);

            var actual = Assert.Throws<DuplicateNewsException>(() => service.AddToFavourite(news));
            Assert.Equal("A news with the title Test Title already exsist", actual.Message);
        }

        [Fact]
        public void RemoveFromFavouriteShouldThrowException()
        {
            var mockRepo = new Mock<INewsRepository>();
            News news = new News
            {
                NewsId = 2,
                Title = "Test Title 2",
                Description = "This is News description",
                Content = "This is News content",
                UrlToImage = "http://www.google.com/google.png",
                Url = "http://www.google.com",
                AddedToFavourite = true
            };

            mockRepo.Setup(repo => repo.RemoveFromFavourite(news)).Returns(false);
            var service = new NewsService(mockRepo.Object, null);

            var actual = Assert.Throws<NewsNotFoundException>(() => service.RemoveFromFavourite(news));

            Assert.Equal("A news with the title Test Title 2 does not exist", actual.Message);
        }

        private List<News> GetAllNews()
        {
            List<News> news = new List<News>
            {
                new News
                {
                    NewsId = 1,
                    Title = "Test Title",
                    Description = "This is News description",
                    Content = "This is News content",
                    UrlToImage = "http://www.google.com/google.png",
                    Url = "http://www.google.com",
                    AddedToFavourite = true
                },
            };

            return news;
        }
    }
}
