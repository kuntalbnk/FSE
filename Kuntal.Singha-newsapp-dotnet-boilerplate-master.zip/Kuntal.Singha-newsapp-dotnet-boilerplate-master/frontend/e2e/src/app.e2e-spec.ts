import { AppPage } from './app.po';
import { browser, logging } from 'protractor';

describe('workspace-project App', () => {
  let page: AppPage;

  beforeEach(() => {
    page = new AppPage();
  });

  it('should login to dashboard', () => {
    page.navigateTo();
    page.setUsername();
    page.setPassword();
    page.getLoginButton().click();
    expect(page.getTitleText()).toEqual('Welcome Kuntal Singha');
  });

  it('should have Top Heading section', () => {
    page.navigateTo();
    page.setUsername();
    page.setPassword();
    page.getLoginButton().click();    
    expect(page.getTopHeadingText()).toEqual('Top Heading');
  });

  it('should have Trending News section', () => {
    page.navigateTo();
    page.setUsername();
    page.setPassword();
    page.getLoginButton().click();
    expect(page.getTrendingNewsText()).toEqual('Trending News');
  });

  it('should have searching facility', () => {
    page.navigateTo();
    page.setUsername();
    page.setPassword();
    page.getLoginButton().click();
    page.setSearchText();
    page.getSearchButton().click();
    expect(page.getSearchHeaderText()).toEqual('India News');
  });

  it('should have search result', () => {
    page.navigateTo();
    page.setUsername();
    page.setPassword();
    page.getLoginButton().click();
    page.setSearchText();
    page.getSearchButton().click();
    expect(page.getSearchResult().isPresent()).toBeTruthy();
  });

  it('should have favourite news', () => {
    page.navigateTo();
    page.setUsername();
    page.setPassword();
    page.getLoginButton().click();
    page.getFavouriteLink().click();
    expect(page.getFavouriteResult().isPresent()).toBeTruthy();
  });

  it('should add to favourite news', () => {
    page.navigateTo();
    page.setUsername();
    page.setPassword();
    page.getLoginButton().click();
    page.getFirstAddToFavouriteButton().click();
    page.getFavouriteLink().click();
    expect(page.getFavouriteResult().isPresent()).toBeTruthy();
  });

  it('should remove from favourite news', () => {
    page.navigateTo();
    page.setUsername();
    page.setPassword();
    page.getLoginButton().click();
    page.getFirstRemoveFromFavouriteButton().click();
    page.getFavouriteLink().click();
    expect(page.getFavouriteResult().isPresent()).toBeTruthy();
  });

  afterEach(async () => {
    // Assert that there are no errors emitted from the browser
    const logs = await browser.manage().logs().get(logging.Type.BROWSER);
    expect(logs).not.toContain(jasmine.objectContaining({
      level: logging.Level.SEVERE,
    } as logging.Entry));
  });
});
