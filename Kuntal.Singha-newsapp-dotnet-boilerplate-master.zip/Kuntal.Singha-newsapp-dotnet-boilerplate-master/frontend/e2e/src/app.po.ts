import { browser, by, element } from 'protractor';

export class AppPage {
  navigateTo() {
    return browser.get(browser.baseUrl) as Promise<any>;
  }

  setUsername() {
    return element(by.id('username')).sendKeys("598794");
  }

  setPassword() {
    return element(by.id('password')).sendKeys("598794");
  }

  getLoginButton() {
    return element(by.cssContainingText('button', 'Login'));
  }

  getTitleText() {
    return element(by.css('.avatar-name')).getText() as Promise<string>;
  }

  getTopHeadingText() {
    return element(by.css('.top-heading')).getText() as Promise<string>;
  }

  getTrendingNewsText() {
    return element(by.css('.trending-news')).getText() as Promise<string>;
  }

  setSearchText() {
    return element(by.id('search-text')).sendKeys("India");
  }

  getSearchButton() {
    return element(by.id('search-btn'));
  }

  getSearchHeaderText() {
    return element(by.css('.search-news')).getText() as Promise<string>;
  }

  getSearchResult() {
    return element(by.css('.news-card'));
  }

  getFavouriteLink() {
    return element(by.id('lnkFavourite'));
  }

  getFavouriteResult() {
    return element(by.css('.news-card'));
  }

  getFirstAddToFavouriteButton() {
    return element.all(by.cssContainingText('button', 'Add to Favourite')).first();
  }

  getFirstRemoveFromFavouriteButton(){
    return element.all(by.cssContainingText('button', 'Remove from Favourite')).first();
  }
}
