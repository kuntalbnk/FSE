import { Injectable, Directive } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

import { User } from '../model';

@Injectable({
  providedIn: 'root'
})
export class GlobalService {
  private userSource = new BehaviorSubject(new User());
  loggedInUser = this.userSource.asObservable();

  constructor() { }

  setUser(user: User) {
    this.userSource.next(user);
  }
}