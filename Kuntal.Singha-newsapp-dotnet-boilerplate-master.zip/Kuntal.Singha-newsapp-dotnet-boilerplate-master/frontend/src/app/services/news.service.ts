import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

import { GlobalService } from './global.service';
import { URL } from './url';
import { User, News } from '../model';


@Injectable({
  providedIn: 'root'
})
export class NewsService {
  apiURL: string;
  user: User = new User();
  headers: HttpHeaders;

  constructor(
    private httpClient: HttpClient,
    private globalService: GlobalService
  ) {
    this.apiURL = URL.news_service;
    this.globalService.loggedInUser.subscribe(user => {
      this.user = user;
      this.headers = new HttpHeaders({ 'Authorization': `Bearer ${this.user.Token}` });
    });
  }

  getNewsCategoryWise(category): Observable<any> {
    return this.httpClient.get(`${this.apiURL}${category}/${this.user.UserId}`, { headers: this.headers });
  }

  getTopHeading(): Observable<any> {
    return this.httpClient.get(`${this.apiURL}top_heading/${this.user.UserId}`, { headers: this.headers });
  }

  search(key: string): Observable<any> {
    return this.httpClient.get(`${this.apiURL}search_news/${key}/${this.user.UserId}`, { headers: this.headers });
  }

  getFavouriteNews(): Observable<any> {
    return this.httpClient.get(`${this.apiURL}favourite/${this.user.UserId}`, { headers: this.headers });
  }

  addToFavourite(news: News): Observable<any> {
    return this.httpClient.post<News>(`${this.apiURL}add_to_favourite`, news, { headers: this.headers });
  }

  removeFromFavourite(news: News): Observable<any> {
    return this.httpClient.post<News>(`${this.apiURL}remove_from_favourite`, news, { headers: this.headers });
  }
}
