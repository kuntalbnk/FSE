import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { URL } from './url';
import { User } from '../model';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  apiURL: string;

  constructor(private httpClient: HttpClient) {
    this.apiURL = URL.auth_service;
  }

  login(user): Observable<any> {
    return this.httpClient.post(`${this.apiURL}/login`, user);
  }

  registration(user): Observable<any> {
    return this.httpClient.post(`${this.apiURL}/register`, user);
  }

  getUserDetails(user): Observable<any> {
    return this.httpClient.post(`${this.apiURL}/profile`, user);
  }

}
