import { TestBed } from '@angular/core/testing';

import { HttpClientModule } from '@angular/common/http';

import { LoginService } from './login.service';

describe('LoginService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    imports: [HttpClientModule],
  }));

  it('should be created', () => {
    const service: LoginService = TestBed.get(LoginService);
    expect(service).toBeTruthy();
  });

  it('should login', () => {
    const service: LoginService = TestBed.get(LoginService);
    service.login({ UserId: '598794', Password: '598794' }).subscribe(res => {
      expect(res).toBeTruthy();
    });
  });

  it('should get user details', () => {
    const service: LoginService = TestBed.get(LoginService);
    service.getUserDetails({ UserId: '598794' }).subscribe(res => {
      expect(res).toBeTruthy();
    });
  });
});
