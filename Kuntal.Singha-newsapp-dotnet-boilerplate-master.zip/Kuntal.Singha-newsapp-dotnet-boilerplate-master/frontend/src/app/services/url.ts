export const URL = {
    auth_service: "http://localhost:8081/auth",
    news_service: 'http://localhost:8082/api/news/',
    //auth_service: "http://localhost:5000/auth",
    //news_service: 'http://localhost:55375/api/news/',
}
