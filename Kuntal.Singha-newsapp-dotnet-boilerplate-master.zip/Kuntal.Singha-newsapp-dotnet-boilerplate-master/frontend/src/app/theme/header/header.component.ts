import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import { GlobalService } from '../../services/global.service';
import { User } from 'src/app/model';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css'],
})
export class HeaderComponent implements OnInit {
  private user: User = new User();
  private searchText: string;
  private isCollapsed = true;

  constructor(
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private globalService: GlobalService
  ) {
    this.globalService.loggedInUser.subscribe(user => {
      this.user = user;
    });
  }

  ngOnInit() {
  }

  search() {
    this.activatedRoute.params.subscribe(params => {
      this.router.navigateByUrl(this.router.createUrlTree(['/search', this.searchText]));
    });
  }

  logout() {
    this.globalService.setUser(new User());
    this.router.navigate(['/login']);
  }

}
