export class User {
    public UserId: string
    public Password: string
    public FirstName: string
    public LastName: string
    public Role: string
    public AddedDate: Date
    public Token: string
}