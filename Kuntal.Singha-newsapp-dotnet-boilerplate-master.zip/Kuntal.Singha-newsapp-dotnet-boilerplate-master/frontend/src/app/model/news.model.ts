export class News {
    public newsId: number
    public title: string
    public description: string
    public urlToImage: string
    public url: string
    public content: string
    public userId: string
    public addedToFavourite: boolean
}