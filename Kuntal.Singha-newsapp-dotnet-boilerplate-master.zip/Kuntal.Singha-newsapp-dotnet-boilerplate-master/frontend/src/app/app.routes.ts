import { Routes, RouterModule, PreloadAllModules } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';

import { PageNotFoundComponent } from './pages/page-not-found/page-not-found.component';

export const routes: Routes = [
    { path: '', redirectTo: '', pathMatch: 'full' },
    { path: '', loadChildren: './pages/pages.module#PagesModule' },
    { path: 'login', loadChildren: './pages/login/login.module#LoginModule' },
    { path: 'registration', loadChildren: './pages/registration/registration.module#RegistrationModule' },
    { path: '**', component: PageNotFoundComponent }
];

export const routing: ModuleWithProviders = RouterModule.forRoot(routes, {
    preloadingStrategy: PreloadAllModules,
    // useHash: true
});