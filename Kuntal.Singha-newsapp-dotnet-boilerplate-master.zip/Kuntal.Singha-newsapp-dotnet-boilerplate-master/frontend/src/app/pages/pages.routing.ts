import { Routes, RouterModule } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';

import { PagesComponent } from './pages.component';

export const routes: Routes = [
    {
        path: '',
        component: PagesComponent,
        children: [
            { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
            { path: 'dashboard', loadChildren: './dashboard/dashboard.module#DashboardModule', data: { title: 'Dashboard' } },
            { path: 'favourite', loadChildren: './favourite/favourite.module#FavouriteModule', data: { title: 'Favourite' } },
            { path: 'search/:searchtext', loadChildren: './news-search/news-search.module#NewsSearchModule', data: { title: 'News Search' } },
        ]
    }
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);