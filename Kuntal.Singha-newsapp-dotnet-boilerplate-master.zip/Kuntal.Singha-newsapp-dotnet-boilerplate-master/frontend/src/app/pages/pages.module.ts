import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { routing } from './pages.routing';
import { AngularMaterialModule } from '../module/angular-material/angular-material.module';
import { BootstrapModule } from '../module/bootstrap/bootstrap.module';

import { HeaderComponent } from '../theme/header/header.component';
import { FooterComponent } from '../theme/footer/footer.component';
import { PagesComponent } from './pages.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    AngularMaterialModule,
    BootstrapModule,
    routing,
  ],
  declarations: [
    PagesComponent,
    HeaderComponent,
    FooterComponent,
  ]
})
export class PagesModule { }
