import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { NewsService } from '../services/news.service';
import { GlobalService } from 'src/app/services/global.service';

@Component({
  selector: 'app-pages',
  templateUrl: './pages.component.html',
  styleUrls: ['./pages.component.css']
})
export class PagesComponent implements OnInit {

  constructor(
    private router: Router,
    private newsService: NewsService,
    private globalService: GlobalService
  ) {
    this.globalService.loggedInUser.subscribe(user => {
      if (Object.keys(user).length == 0) {
        this.router.navigateByUrl('/login');
      }
    });
  }

  ngOnInit() { }
}
