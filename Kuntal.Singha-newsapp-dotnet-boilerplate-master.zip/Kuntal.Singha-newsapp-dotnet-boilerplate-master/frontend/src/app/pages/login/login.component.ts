import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { LoginService } from '../../services/login.service';
import { GlobalService } from '../../services/global.service';

import { User } from '../../model';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  private user: User = new User();

  constructor(
    private router: Router,
    private loginService: LoginService,
    private globalService: GlobalService
  ) { }

  ngOnInit() {
  }

  login() {
    this.loginService.login(this.user)
      .subscribe(res => {
        if (res) {
          this.loginService.getUserDetails({ "UserId": this.user.UserId })
            .subscribe(user => {
              this.user.FirstName = user.firstName;
              this.user.LastName = user.lastName;
              this.user.Password = user.password;
              this.user.Role = user.role;
              this.user.Token = res.token;

              this.globalService.setUser(this.user);
              this.router.navigateByUrl('/dashboard');
            });
        }
        else {
          alert('Invalid credential');
        }
      }, error => {
        alert('Invalid credential');
      });
  }
}
