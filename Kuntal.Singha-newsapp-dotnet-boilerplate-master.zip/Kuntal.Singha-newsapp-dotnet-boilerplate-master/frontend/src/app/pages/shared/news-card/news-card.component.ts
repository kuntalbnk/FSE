import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { News } from 'src/app/model';
import { NewsService } from 'src/app/services/news.service';

@Component({
  selector: 'app-news-card',
  templateUrl: './news-card.component.html',
  styleUrls: ['./news-card.component.css']
})
export class NewsCardComponent implements OnInit {
  @Input() news: News;
  @Output() removeButtonClicked = new EventEmitter<boolean>();
  @Output() addButtonClicked = new EventEmitter<boolean>();

  constructor(
    private newsService: NewsService
  ) { }

  ngOnInit() {
    if (this.news.content == null) {
      this.news.content = "";
    }
    if (this.news.description == null) {
      this.news.description = "";
    }
  }

  addToFavourite() {
    this.newsService.addToFavourite(this.news)
      .subscribe(res => {
        if (res) {
          this.addToFavouriteButtonClicked();
          this.news.addedToFavourite = true;
        }
      }, error => {
        alert("Failed to add news to favourite.");
      });
  }

  removeFromFavourite() {
    this.newsService.removeFromFavourite(this.news)
      .subscribe(res => {
        if (res) {
          this.removeFromFavouriteButtonClicked();
          this.news.addedToFavourite = false;
        }
      }, error => {
        alert("Failed to remove news from favourite.");
      });
  }

  removeFromFavouriteButtonClicked() {
    this.removeButtonClicked.emit(true);
  }

  addToFavouriteButtonClicked() {
    this.addButtonClicked.emit(true);
  }
}
