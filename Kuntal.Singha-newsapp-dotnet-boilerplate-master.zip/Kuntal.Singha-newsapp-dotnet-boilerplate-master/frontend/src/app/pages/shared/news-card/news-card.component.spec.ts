import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HttpClientModule } from '@angular/common/http';
import { AngularMaterialModule } from '../../../module/angular-material/angular-material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { NewsService } from '../../../services/news.service';

import { NewsCardComponent } from './news-card.component';

describe('NewsCardComponent', () => {
  let component: NewsCardComponent;
  let fixture: ComponentFixture<NewsCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [NewsCardComponent],
      imports: [BrowserAnimationsModule, FormsModule, HttpClientModule, ReactiveFormsModule, AngularMaterialModule],
      providers: [NewsService]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewsCardComponent);
    component = fixture.componentInstance;
    component.news = {
      newsId: 1,
      title: 'News Title',
      description: 'News Description',
      content: 'News Content',
      urlToImage: 'https://i.stack.imgur.com/GNhxO.png',
      url: 'http://canamerica.adsfreevideos.com/news/sjws-cheer-no-men-in-image-for-new-terminator-movie-ben-davies?uid=190352',
      addedToFavourite: true,
      userId: '123456'
    };
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
