import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { NewsCardModule } from '../../module/news-card/news-card.module';
import { AngularMaterialModule } from '../../module/angular-material/angular-material.module';
import { BootstrapModule } from '../../module/bootstrap/bootstrap.module';

import { FavouriteComponent } from './favourite.component';

export const routes = [
  { path: '', component: FavouriteComponent, pathMatch: 'full' }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    AngularMaterialModule,
    BootstrapModule,
    NewsCardModule,
    RouterModule.forChild(routes)
  ],
  declarations: [
    FavouriteComponent
  ]
})
export class FavouriteModule { }
