import { Component, OnInit } from '@angular/core';

import { NewsService } from 'src/app/services/news.service';
import { News } from 'src/app/model';

@Component({
  selector: 'app-favourite',
  templateUrl: './favourite.component.html',
  styleUrls: ['./favourite.component.css']
})
export class FavouriteComponent implements OnInit {
  private favouriteNews: News[] = [];

  constructor(
    private newsService: NewsService,
  ) { }

  ngOnInit() {
    this.fetchFavouriteNews();
  }

  fetchFavouriteNews() {
    this.newsService.getFavouriteNews()
      .subscribe(res => {
        if (res) {
          this.favouriteNews = res;
        }
      });
  }

  handleRemoveButtonClicked($event) {
    if ($event) {
      this.fetchFavouriteNews();
    }
  }

}
