import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { NewsService } from 'src/app/services/news.service';

import { News } from 'src/app/model';

@Component({
  selector: 'app-news-search',
  templateUrl: './news-search.component.html',
  styleUrls: ['./news-search.component.css']
})
export class NewsSearchComponent implements OnInit {
  public searchKey: string;
  public searchedNews: News[] = [];

  constructor(
    private activatedRoute: ActivatedRoute,
    private newsService: NewsService,
  ) {
    this.activatedRoute.params.subscribe(params => {
      this.searchKey = params["searchtext"];
      this.getSearchedNews(this.searchKey);
    });
  }

  ngOnInit() { }

  getSearchedNews(key) {
    this.newsService.search(this.searchKey)
      .subscribe(news => {
        this.searchedNews = news;
      });
  }

}
