import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { NewsCardModule } from '../../module/news-card/news-card.module';
import { AngularMaterialModule } from '../../module/angular-material/angular-material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { NewsService } from '../../services/news.service';
import { GlobalService } from 'src/app/services/global.service';

import { NewsSearchComponent } from './news-search.component';

describe('NewsSearchComponent', () => {
  let component: NewsSearchComponent;
  let fixture: ComponentFixture<NewsSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [NewsSearchComponent],
      imports: [BrowserAnimationsModule, FormsModule, HttpClientModule, RouterTestingModule, ReactiveFormsModule, NewsCardModule, AngularMaterialModule],
      providers: [NewsService, GlobalService]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewsSearchComponent);
    component = fixture.componentInstance;
    component.searchKey = "";
    component.searchedNews = [
      {
        newsId: 1,
        title: 'News Title',
        description: 'News Description',
        content: 'News Content',
        urlToImage: 'https://i.stack.imgur.com/GNhxO.png',
        url: 'http://canamerica.adsfreevideos.com/news/sjws-cheer-no-men-in-image-for-new-terminator-movie-ben-davies?uid=190352',
        addedToFavourite: true,
        userId: '123456'
      },
    ];
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
