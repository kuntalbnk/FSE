import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';

import { NewsSearchComponent } from './news-search.component';

import { NewsCardModule } from '../../module/news-card/news-card.module';
import { AngularMaterialModule } from '../../module/angular-material/angular-material.module';
import { BootstrapModule } from '../../module/bootstrap/bootstrap.module';

export const routes = [
  { path: '', component: NewsSearchComponent, pathMatch: 'full' }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    FormsModule,
    AngularMaterialModule,
    BootstrapModule,
    NewsCardModule,
  ],
  declarations: [
    NewsSearchComponent,
  ]
})

export class NewsSearchModule { }
