import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { LoginService } from '../../services/login.service';
import { User } from 'src/app/model';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  user: User = new User();

  constructor(
    private router: Router,
    private loginService: LoginService,
  ) { }

  ngOnInit() {
  }

  registration() {
    if (this.user.UserId.length > 0
      && this.user.Password.length > 0
      && this.user.FirstName.length > 0
      && this.user.LastName.length > 0) {
      this.user.Role = "Admin";
      this.user.AddedDate = new Date();
      this.loginService.registration(this.user)
        .subscribe(res => {
          if (res) {
            alert('User registered successfully');
            this.router.navigateByUrl('/login');
          }
          else {
            alert('User registration failed');
          }
        }, error => {
          if (error.status == 409) {
            alert(error.error);
          }
          else {
            alert('User registration failed');
          }
        });
    }
    else {
      alert("Please enter required input");
    }
  }

}
