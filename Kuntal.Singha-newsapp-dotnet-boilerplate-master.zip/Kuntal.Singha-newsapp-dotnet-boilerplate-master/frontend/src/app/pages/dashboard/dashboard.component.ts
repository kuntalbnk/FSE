import { Component, OnInit } from '@angular/core';

import { NewsService } from '../../services/news.service';
import { GlobalService } from 'src/app/services/global.service';
import { News, User } from 'src/app/model';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
})
export class DashboardComponent implements OnInit {
  private user: User = new User();
  topHeading: News[] = [];
  categoriseNews: News[] = [];
  cetegory: string = "general";

  constructor(
    private newsService: NewsService,
    private globalService: GlobalService
  ) { }

  ngOnInit() {
    this.globalService.loggedInUser.subscribe(user => {
      if (Object.keys(user).length > 0) {
        this.fetchTopHeading();
        this.fetchNewsCatigoryWise(this.cetegory);
      }
    });
  }

  loadCategory() {
    this.categoriseNews = [];
    this.fetchNewsCatigoryWise(this.cetegory);
  }

  fetchTopHeading() {
    this.newsService.getTopHeading()
      .subscribe(news => {
        this.topHeading = news;
      });
  }

  fetchNewsCatigoryWise(catg) {
    this.newsService.getNewsCategoryWise(catg)
      .subscribe(news => {
        this.categoriseNews = news;
      });
  }

}
