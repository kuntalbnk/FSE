import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HttpClientModule } from '@angular/common/http';
import { NewsCardModule } from '../../module/news-card/news-card.module';
import { AngularMaterialModule } from '../../module/angular-material/angular-material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { NewsService } from '../../services/news.service';
import { GlobalService } from 'src/app/services/global.service';

import { DashboardComponent } from './dashboard.component';

describe('DashboardComponent', () => {
  let component: DashboardComponent;
  let fixture: ComponentFixture<DashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [DashboardComponent],
      imports: [BrowserAnimationsModule, FormsModule, HttpClientModule, ReactiveFormsModule, NewsCardModule, AngularMaterialModule],
      providers: [NewsService, GlobalService]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DashboardComponent);
    component = fixture.componentInstance;
    component.topHeading = [
      {
        newsId: 1,
        title: 'News Title',
        description: 'News Description',
        content: 'News Content',
        urlToImage: 'https://i.stack.imgur.com/GNhxO.png',
        url: 'http://canamerica.adsfreevideos.com/news/sjws-cheer-no-men-in-image-for-new-terminator-movie-ben-davies?uid=190352',
        addedToFavourite: true,
        userId: '123456'
      },
    ];
    component.categoriseNews = [
      {
        newsId: 2,
        title: 'General News Title',
        description: 'News Description',
        content: 'News Content',
        urlToImage: 'https://i.stack.imgur.com/GNhxO.png',
        url: 'http://canamerica.adsfreevideos.com/news/sjws-cheer-no-men-in-image-for-new-terminator-movie-ben-davies?uid=190352',
        addedToFavourite: true,
        userId: '123456'
      },
    ];
    component.cetegory = 'general';
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
