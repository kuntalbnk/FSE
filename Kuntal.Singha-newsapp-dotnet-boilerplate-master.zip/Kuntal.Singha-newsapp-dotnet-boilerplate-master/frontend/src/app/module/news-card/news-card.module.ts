import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NewsCardComponent } from '../../pages/shared/news-card/news-card.component';
import { AngularMaterialModule } from '../../module/angular-material/angular-material.module';

@NgModule({
  declarations: [NewsCardComponent],
  imports: [
    CommonModule,
    AngularMaterialModule,
  ],
  exports: [NewsCardComponent],
})
export class NewsCardModule { }
