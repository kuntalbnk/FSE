﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UserService.API.Exceptions;
using UserService.API.Models;
using UserService.API.Repository;

namespace UserService.API.Service
{
    public class UserService : IUserService
    {
        public readonly IUserRepository repository;

        public UserService(IUserRepository userRepository)
        {
            repository = userRepository;
        }

        public List<User> GetAllUser()
        {
            return repository.GetAllUser();
        }

        public bool DeleteUser(string userId)
        {
            try
            {
                if (repository.DeleteUser(userId))
                {
                    return true;
                }
                else
                {
                    throw new Exception();
                }
            }
            catch
            {
                throw new UserNotFoundException("This user id does not exist");
            }
        }

        public User GetUserById(string userId)
        {
            User user;
            try
            {
                user = repository.GetUserById(userId);
                if (ReferenceEquals(user, null))
                {
                    throw new Exception();
                }
            }
            catch
            {
                throw new UserNotFoundException("This user id does not exist");
            }
            return user;
        }

        public User RegisterUser(User user)
        {
            User createdUser;
            try
            {
                createdUser = repository.RegisterUser(user);
                if (ReferenceEquals(createdUser, null))
                {
                    throw new Exception();
                }
            }
            catch
            {
                throw new UserNotCreatedException("This user id already exists");
            }

            return createdUser;
        }

        public bool UpdateUser(string userId, User user)
        {
            try
            {
                if (repository.UpdateUser(userId, user))
                {
                    return true;
                }
                else
                {
                    throw new Exception();
                }
            }
            catch
            {
                throw new UserNotFoundException("This user id does not exist");
            }
        }
    }
}
