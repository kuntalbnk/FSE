﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MongoDB.Driver;
using ReminderService.API.Models;

namespace ReminderService.API.Repository
{
    public class ReminderRepository : IReminderRepository
    {
        public readonly IReminderContext context;

        public ReminderRepository(IReminderContext dbContext)
        {
            context = dbContext;
        }

        public Reminder CreateReminder(Reminder reminder)
        {
            context.Reminders.InsertOne(reminder);
            return reminder;
        }

        public bool DeleteReminder(int reminderId)
        {
            var result = context.Reminders.DeleteOne(i => i.Id == reminderId);
            return result.IsAcknowledged && result.DeletedCount > 0;
        }

        public List<Reminder> GetAllReminders()
        {
            return context.Reminders.Find(_ => true).ToList();
        }

        public Reminder GetReminderById(int reminderId)
        {
            return context.Reminders.Find(i => i.Id == reminderId).FirstOrDefault();
        }

        public bool UpdateReminder(int reminderId, Reminder reminder)
        {
            var result = context.Reminders.ReplaceOne(filter: c => c.Id == reminderId, replacement: reminder);
            return result.IsAcknowledged && result.ModifiedCount > 0;
        }
    }
}
