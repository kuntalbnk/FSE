﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using CategoryService.API.Service;
using CategoryService.API.Models;
using CategoryService.API.Exceptions;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CategoryService.API.Controllers
{
    [ExceptionHandler]
    [LoggingAspect]
    [Route("api/[controller]")]
    public class CategoryController : Controller
    {
        private readonly ICategoryService service;

        public CategoryController(ICategoryService _service)
        {
            this.service = _service;
        }
        // GET: api/<controller>
        [HttpGet]
        public IActionResult Get(int categoryId)
        {
            return Ok(service.GetCategoryById(categoryId));
        }

        // GET api/<controller>/5
        [HttpGet]
        public IActionResult Get(string userId)
        {
            return Ok(service.GetAllCategoriesByUserId(userId));
        }

        // POST api/<controller>
        [HttpPost]
        public IActionResult Post(Category category)
        {
            return Created("", service.CreateCategory(category));
        }

        // PUT api/<controller>/5
        [HttpPut("{id}")]
        public IActionResult Put(int id, Category category)
        {
            return Ok(service.UpdateCategory(id, category));
        }

        // DELETE api/<controller>/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            return Ok(service.DeleteCategory(id));
        }
    }
}
