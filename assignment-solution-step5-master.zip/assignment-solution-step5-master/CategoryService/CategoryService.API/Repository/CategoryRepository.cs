﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CategoryService.API.Models;
using MongoDB.Driver;

namespace CategoryService.API.Repository
{
    public class CategoryRepository : ICategoryRepository
    {
        private readonly ICategoryContext context;
        public CategoryRepository(ICategoryContext dbContext)
        {
            context = dbContext;
        }
        public Category CreateCategory(Category category)
        {
            context.Categories.InsertOne(category);
            return category;
        }

        public bool DeleteCategory(int categoryId)
        {
            var result = context.Categories.DeleteOne(i => i.Id == categoryId);
            return result.IsAcknowledged && result.DeletedCount > 0;
        }

        public List<Category> GetAllCategoriesByUserId(string userId)
        {
            return context.Categories.Find(i => i.CreatedBy == userId).ToList();
        }

        public Category GetCategoryById(int categoryId)
        {
            return context.Categories.Find(i => i.Id == categoryId).FirstOrDefault();
        }

        public bool UpdateCategory(int categoryId, Category category)
        {
            var result = context.Categories.ReplaceOne(filter: c => c.Id == categoryId, replacement: category);
            return result.IsAcknowledged && result.ModifiedCount > 0;
        }
    }
}
