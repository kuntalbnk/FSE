﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using MongoDB.Driver;

namespace CategoryService.API.Models
{
    public class CategoryContext : ICategoryContext
    {
        MongoClient mongoClient;
        IMongoDatabase database;

        public CategoryContext(IConfiguration configuration)
        {
            mongoClient = new MongoClient(configuration.GetSection("MongoDB:ConnectionString").Value);
            database = mongoClient.GetDatabase(configuration.GetSection("MongoDB:Database").Value);
        }
        public IMongoCollection<Category> Categories => database.GetCollection<Category>("Categories");
    }
}
